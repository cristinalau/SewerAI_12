# SEWERAI_SYNC config patch

This patched composite removes the hard-coded SewerAI `ACCOUNT_SID` and `Authorization` API key from `SendWOTChanges.bpel`.

## What changed

1. Added BPEL variable `vAccountSid`.
2. In `EncodeAndSetOpaquePayload`, the Java Embedding now reads:

```sql
SELECT ACCOUNT_SID, API_AUTHORIZATION
FROM CUSTOMERDATA.EPSEWERAI_SYNC_CONFIG
WHERE PROCESS_NAME = 'SEWERAI_SYNC'
  AND IS_ENABLED = 'Y'
```

3. The Java payload uses the DB-sourced `ACCOUNT_SID`.
4. The REST Authorization header uses the DB-sourced `API_AUTHORIZATION`.
5. The `PutProjectsRequest` assignment now maps account SID from `$vAccountSid`.

## Important check

The Java lookup uses this datasource JNDI name:

```java
jdbc/Ivara/Ivara/NonXA
```

If your WebLogic datasource JNDI name is different, change this line inside `SendWOTChanges.bpel`:

```java
final String CONFIG_DATASOURCE     = "jdbc/Ivara/Ivara/NonXA";
```

## SQL

Use `SOA/sql/01_setup_sewerai_config_row.sql` to insert/update the one config row.

For `API_AUTHORIZATION`, store the full header value, for example:

```text
X-SAI your_actual_key_here
```

Do not store only the raw key unless SewerAI expects no `X-SAI` prefix.
